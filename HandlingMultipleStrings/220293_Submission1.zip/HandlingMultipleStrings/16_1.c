/*How many bytes in memory would be occupied by the following 
array of pointers to strings? How many bytes would be required to 
store the same strings in a two-dimensional character array? 
char  *mess[ ] = {  
  
   "Hammer and tongs", "Tooth and nail",  
   "Spit and polish", "You and C"  
   } ;
*/
/*A hospital keeps a file of blood donors in which each record has the 
format: 
Name: 20 columns      Address: 40 columns 
Age: 2 columns        Blood Type: 1 column (Type 1, 2, 3 or 4) 

Write a program to read these records, arrange them in ascending 
order by join_date and write them to a target file. 

*/
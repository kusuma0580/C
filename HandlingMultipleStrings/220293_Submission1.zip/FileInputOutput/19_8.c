/* Given a list of names of students in a class, write a program to store 
the names in a file on disk. Make a provision to display the nth name 
in the list, where n is read from the keyboard. */
/*Given a text file, write a program to create another text file deleting 
the words “a”, “the”, “an” and replacing each one of them with a 
blank space.*/
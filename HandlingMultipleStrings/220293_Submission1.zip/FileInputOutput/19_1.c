/*Suppose a file contains student records with each record containing 
name and age of a student. Write a program to read these records 
and display them in sorted order by name.*/
/*There are 10 records present in a file with the following structure: 
struct  date { int  d, m, y ; } ; 
struct  employee 
{ 
    int  empcode[ 6 ] ;  char  empname[ 20 ] ;  
    struct  date join_date ;  float  salary ; 
} ; 
Write a program to read these records, arrange them in ascending 
order by join_date and write them to a target file.  
*/
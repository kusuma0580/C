/* Write a program that merges lines alternately from two files and 
writes the results to a new file. If one file has a smaller number of 
lines than the other, the remaining lines from the larger file should 
be simply copied into the target file. 
*/
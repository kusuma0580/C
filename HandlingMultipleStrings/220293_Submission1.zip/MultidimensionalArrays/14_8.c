/*Given an array p[ 5 ], write a function to shift it circularly left by two 
positions. Thus, if the original array is { 15, 30, 28, 19, 61 } then after 
shifting it will be { 28, 19, 61, 15, 30 } Call this function for a 4 x 5 
matrix and get its rows left shifted.*/
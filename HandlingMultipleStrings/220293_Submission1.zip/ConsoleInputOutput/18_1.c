/* To receive the string "We have got the guts, you get the glory!!" in 
an array char str[ 100 ] which of the following functions would you 
use? 
1. scanf ( "%s", str ) ; 
2. gets ( str ) ; 
3. getchar ( str ) ; 
4. fgetchar ( str ) ; */

//2)gets(str)


/* If an integer is to be entered through the keyboard, which function 
would you use? 
1. scanf( ) 
2. gets( ) 
3. getche( )  
4. getchar( )  */

//1)scanf()
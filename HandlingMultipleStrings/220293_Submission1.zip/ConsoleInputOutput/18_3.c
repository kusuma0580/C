/*Which of the following can a format string of a printf( ) function 
contain: 
1. Characters, format specifications and escape sequences 
2. Character, integers and floats 
3. Strings, integers and escape sequences 
4. Inverted commas, percentage sign and backslash character */

//1)Characters, format specifications, and escape sequences.
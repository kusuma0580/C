/* The purpose of the field-width specifier in a printf( ) function is to: 
1. Control the margins of the program listing 
2. Specify the maximum value of a number 
3. Control the size of font used to print numbers 
4. Specify how many columns should be used to print the number */

//4)Specify how many columns should be used to print the number